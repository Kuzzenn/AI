"""
Energy Consumption: Preprocessing & Simple Forecasting
This script preprocesses hourly energy consumption data, visualizes trends,
implements three simple forecasting methods (Naive, Simple Average, Rolling Average),
and evaluates them using MFE, MAE, and MAPE metrics.
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
from sklearn.metrics import mean_absolute_error

# Configure plotting
plt.style.use('seaborn-v0_8-darkgrid')
sns.set_palette('husl')
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', 100)

print("=" * 70)
print("ENERGY CONSUMPTION: PREPROCESSING & SIMPLE FORECASTING")
print("=" * 70)

# ============================================================================
# 1. Load and inspect dataset
# ============================================================================
print("\n[1] Loading and inspecting dataset...")
try:
    df = pd.read_csv('events.csv', header=0)
    print(f"✓ Dataset loaded successfully")
    print(f"  Shape: {df.shape}")
    print(f"  Columns: {df.columns.tolist()}")
    print(f"\nFirst 5 rows:")
    print(df.head())
except FileNotFoundError:
    print(f"✗ Error: events.csv not found in current directory: {os.getcwd()}")
    print(f"  Please run this script from: c:\\Users\\Lenovo\\Desktop\\ai final\\Lab 07\\task\\")
    exit(1)

# ============================================================================
# 2. Preprocess: parse dates and set DatetimeIndex
# ============================================================================
print("\n[2] Preprocessing: parsing dates and setting DatetimeIndex...")
df_clean = df[['Start time UTC+03:00', 'Electricity consumption in Finland']].copy()
df_clean.columns = ['time', 'energy']

df_clean['time'] = pd.to_datetime(df_clean['time'])
df_clean['energy'] = pd.to_numeric(df_clean['energy'], errors='coerce')
df_clean = df_clean.set_index('time').sort_index()

print(f"✓ Preprocessed shape: {df_clean.shape}")
print(f"  Date range: {df_clean.index.min()} to {df_clean.index.max()}")
print(df_clean)
# ============================================================================
# 3. Handle empty/missing inputs
# ============================================================================
print("\n[3] Handling missing values...")
missing_before = df_clean.isnull().sum().sum()
print(f"  Missing values before: {missing_before}")

df_clean['energy'] = df_clean['energy'].interpolate(method='time', limit_direction='both')
df_clean['energy'] = df_clean['energy'].fillna(method='ffill').fillna(method='bfill')

missing_after = df_clean.isnull().sum().sum()
print(f"  Missing values after: {missing_after}")
print(f"✓ Dataset is complete: {missing_after == 0}")

# ============================================================================
# 4. Detect and handle outliers
# ============================================================================
print("\n[4] Detecting and handling outliers (IQR method)...")
Q1 = df_clean['energy'].quantile(0.25)
Q3 = df_clean['energy'].quantile(0.75)
IQR = Q3 - Q1
lower = Q1 - 1.5 * IQR
upper = Q3 + 1.5 * IQR

out_mask = (df_clean['energy'] < lower) | (df_clean['energy'] > upper)
num_outliers = out_mask.sum()
print(f"  Q1: {Q1:.2f}, Q3: {Q3:.2f}, IQR: {IQR:.2f}")
print(f"  Lower bound: {lower:.2f}, Upper bound: {upper:.2f}")
print(f"  Outliers detected: {num_outliers} ({num_outliers/len(df_clean)*100:.4f}%)")

if out_mask.any():
    rm = df_clean['energy'].rolling(window=24, center=True, min_periods=1).median()
    df_clean.loc[out_mask, 'energy'] = rm[out_mask]
    print(f"✓ Outliers replaced with 24-hour rolling median")

print(f"\nStatistics after outlier handling:")
print(df_clean['energy'].describe())

# ============================================================================
# 5. Feature engineering: year, month, day, hour, weekday
# ============================================================================
print("\n[5] Feature engineering: extracting temporal features...")
df_clean['year'] = df_clean.index.year
df_clean['month'] = df_clean.index.month
df_clean['day'] = df_clean.index.day
df_clean['hour'] = df_clean.index.hour
df_clean['weekday'] = df_clean.index.weekday
df_clean['weekday_name'] = df_clean.index.day_name()

print(f"✓ Added temporal features: year, month, day, hour, weekday, weekday_name")

# ============================================================================
# 6. Visualize trends by year, month, and day
# ============================================================================
print("\n[6] Creating trend visualizations...")
fig, axes = plt.subplots(2, 2, figsize=(14, 10))

# Yearly trend
yearly = df_clean.groupby('year')['energy'].sum()
axes[0, 0].bar(yearly.index, yearly.values, color='steelblue', edgecolor='black')
axes[0, 0].set_title('Total Energy Consumption by Year', fontweight='bold')
axes[0, 0].set_xlabel('Year')
axes[0, 0].set_ylabel('Energy (MWh)')
axes[0, 0].grid(alpha=0.3)

# Monthly trend
monthly = df_clean.groupby('month')['energy'].mean()
axes[0, 1].plot(monthly.index, monthly.values, marker='o', linewidth=2, color='darkgreen')
axes[0, 1].fill_between(monthly.index, monthly.values, alpha=0.3, color='lightgreen')
axes[0, 1].set_title('Average Energy Consumption by Month', fontweight='bold')
axes[0, 1].set_xlabel('Month')
axes[0, 1].set_ylabel('Energy (MWh)')
axes[0, 1].set_xticks(range(1, 13))
axes[0, 1].grid(alpha=0.3)

# Hourly trend
hourly = df_clean.groupby('hour')['energy'].mean()
axes[1, 0].bar(hourly.index, hourly.values, color='coral', edgecolor='black')
axes[1, 0].set_title('Average Energy Consumption by Hour of Day', fontweight='bold')
axes[1, 0].set_xlabel('Hour')
axes[1, 0].set_ylabel('Energy (MWh)')
axes[1, 0].set_xticks(range(0, 24, 2))
axes[1, 0].grid(alpha=0.3)

# Weekday trend
weekday_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
weekday_data = [df_clean[df_clean['weekday_name'] == d]['energy'].values for d in weekday_order]
bp = axes[1, 1].boxplot(weekday_data, labels=weekday_order, patch_artist=True)
for patch in bp['boxes']:
    patch.set_facecolor('lightblue')
axes[1, 1].set_title('Energy Distribution by Day of Week', fontweight='bold')
axes[1, 1].set_ylabel('Energy (MWh)')
axes[1, 1].tick_params(axis='x', rotation=45)
axes[1, 1].grid(alpha=0.3, axis='y')

plt.tight_layout()
plt.savefig('energy_trends.png', dpi=300, bbox_inches='tight')
print("✓ Trend visualization saved as 'energy_trends.png'")
plt.show()

# ============================================================================
# 7. Time-based train/test split (80/20)
# ============================================================================
print("\n[7] Creating train/test split (80/20)...")
train_size = int(len(df_clean) * 0.8)
train = df_clean.iloc[:train_size].copy()
test = df_clean.iloc[train_size:].copy()

train_series = train['energy'].values
test_series = test['energy'].values
split_date = train.index[-1]

print(f"✓ Train size: {len(train)} ({len(train)/len(df_clean)*100:.2f}%)")
print(f"  Test size: {len(test)} ({len(test)/len(df_clean)*100:.2f}%)")
print(f"  Train period: {train.index.min()} to {train.index.max()}")
print(f"  Test period: {test.index.min()} to {test.index.max()}")

# ============================================================================
# 8. Implement forecasting methods
# ============================================================================
print("\n[8] Implementing forecasting methods...")

def naive_forecast(train_values, h):
    """Naive forecast: last observed value"""
    return np.full(h, train_values[-1])

def simple_average_forecast(train_values, h):
    """Simple average: mean of all training data"""
    return np.full(h, train_values.mean())

def rolling_average_forecast(train_values, h, window=24):
    """Rolling average: mean of last k observations"""
    return np.full(h, train_values[-window:].mean())

h = len(test)
naive_pred = naive_forecast(train_series, h)
simple_pred = simple_average_forecast(train_series, h)
rolling_pred = rolling_average_forecast(train_series, h, window=24)

print(f"✓ Forecasting methods implemented:")
print(f"  - Naive: {naive_pred[0]:.2f} (last value)")
print(f"  - Simple Average: {simple_pred[0]:.2f} (mean)")
print(f"  - Rolling Average (24h): {rolling_pred[0]:.2f} (mean of last 24h)")

# ============================================================================
# 9. Visualize forecasts on train and test sets
# ============================================================================
print("\n[9] Creating forecast visualizations...")
fig, ax = plt.subplots(1, 1, figsize=(15, 6))

ax.plot(train.index, train['energy'], label='Train Data', color='gray', linewidth=1, alpha=0.7)
ax.plot(test.index, test['energy'], label='Test Data (Actual)', color='blue', linewidth=2)
ax.plot(test.index, naive_pred, label='Naive Forecast', linestyle='--', color='red', linewidth=2)
ax.plot(test.index, simple_pred, label='Simple Average', linestyle='--', color='green', linewidth=2)
ax.plot(test.index, rolling_pred, label='Rolling Average (24h)', linestyle='--', color='orange', linewidth=2)
ax.axvline(split_date, color='black', linestyle=':', linewidth=2, label='Train/Test Split')

ax.set_title('Energy Consumption Forecasts vs Actual Values', fontsize=14, fontweight='bold')
ax.set_xlabel('Time')
ax.set_ylabel('Energy Consumption (MWh)')
ax.legend(loc='best', fontsize=10)
ax.grid(alpha=0.3)

plt.tight_layout()
plt.savefig('forecast_comparison.png', dpi=300, bbox_inches='tight')
print("✓ Forecast visualization saved as 'forecast_comparison.png'")
plt.show()

# ============================================================================
# 10. Evaluation metrics: MFE, MAE, MAPE
# ============================================================================
print("\n[10] Computing evaluation metrics...")

def mfe(y_true, y_pred):
    """Mean Forecast Error"""
    return np.mean(y_pred - y_true)

def mae(y_true, y_pred):
    """Mean Absolute Error"""
    return np.mean(np.abs(y_pred - y_true))

def mape(y_true, y_pred):
    """Mean Absolute Percentage Error"""
    eps = 1e-8
    mask = y_true != 0
    if mask.sum() == 0:
        return np.inf
    return 100 * np.mean(np.abs((y_pred[mask] - y_true[mask]) / (y_true[mask] + eps)))

# Compute metrics for each method
results = {
    'Naive': {
        'MFE': mfe(test_series, naive_pred),
        'MAE': mae(test_series, naive_pred),
        'MAPE': mape(test_series, naive_pred)
    },
    'Simple Average': {
        'MFE': mfe(test_series, simple_pred),
        'MAE': mae(test_series, simple_pred),
        'MAPE': mape(test_series, simple_pred)
    },
    'Rolling Average (24h)': {
        'MFE': mfe(test_series, rolling_pred),
        'MAE': mae(test_series, rolling_pred),
        'MAPE': mape(test_series, rolling_pred)
    }
}

res_df = pd.DataFrame(results).T
print(f"\n{'=' * 70}")
print(f"EVALUATION METRICS ON TEST SET")
print(f"{'=' * 70}")
print(res_df.round(4))
print(f"\nMetric Definitions:")
print(f"  MFE  (Mean Forecast Error): Measures bias (negative = underprediction)")
print(f"  MAE  (Mean Absolute Error): Average absolute difference")
print(f"  MAPE (Mean Absolute Percentage Error): Average percentage error")
print(f"{'=' * 70}\n")

# Save metrics to CSV
res_df.to_csv('forecast_metrics.csv')
print("✓ Metrics saved to 'forecast_metrics.csv'")

# ============================================================================
# Summary
# ============================================================================
print("\n" + "=" * 70)
print("ANALYSIS COMPLETE")
print("=" * 70)
print("\nGenerated files:")
print("  - energy_trends.png: Trend visualization (year, month, hour, weekday)")
print("  - forecast_comparison.png: Forecast comparison visualization")
print("  - forecast_metrics.csv: Evaluation metrics table")
print("\nBest performing method (lowest MAE):")
best_method = res_df['MAE'].idxmin()
print(f"  {best_method}: MAE = {res_df.loc[best_method, 'MAE']:.4f}")
print("=" * 70)
