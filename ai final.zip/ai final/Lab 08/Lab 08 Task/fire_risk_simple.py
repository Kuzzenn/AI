"""
Fire Risk Prediction - Complete Solution
Simple, direct implementation
"""

import os
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.impute import SimpleImputer
import joblib

# Configuration
DATA_DIR = "."
TRAIN_FILE = "fire_risk_train.csv"
TEST_FILE = "fire_risk_test.csv"
OUTPUT_FILE = "fire_risk_submission.csv"

print("=" * 70)
print("FIRE RISK PREDICTION - MACHINE LEARNING SOLUTION")
print("=" * 70)

# ============================================================================
# SECTION 1: LOAD DATA
# ============================================================================
print("\n[1] LOADING DATA...")

df_train = pd.read_csv(TRAIN_FILE)
df_test = pd.read_csv(TEST_FILE)

print(f"    Training samples: {df_train.shape[0]}")
print(f"    Test samples: {df_test.shape[0]}")
print(f"    Features: {df_train.shape[1]}")

# ============================================================================
# SECTION 2: DATA CLEANING
# ============================================================================
print("\n[2] DATA CLEANING...")

# Handle missing values - separate target first
y_train = df_train['fire_risk_score'].values

# Get feature columns (exclude target and unwanted columns)
feature_cols = [col for col in df_train.columns 
                if col not in ['fire_risk_score', 'fire_risk_level', 'random_noise']]

X_train_raw = df_train[feature_cols].copy()
X_test_raw = df_test[feature_cols].copy()

# Impute
imputer = SimpleImputer(strategy='median')
X_train_imputed = imputer.fit_transform(X_train_raw)
X_test_imputed = imputer.transform(X_test_raw)

# Back to dataframes
X_train_df = pd.DataFrame(X_train_imputed, columns=feature_cols)
X_test_df = pd.DataFrame(X_test_imputed, columns=feature_cols)

# ============================================================================
# SECTION 3: FEATURE ENGINEERING
# ============================================================================
print("\n[3] FEATURE ENGINEERING...")

# Select base features (drop random_noise, fire_risk_level)
base_features = ['temperature_C', 'humidity_percent', 'wind_speed_kmph', 
                 'air_quality_index', 'vegetation_index', 'emergency_response_time_min']

# Create interactions
X_train_df['temp_humidity_interaction'] = X_train_df['temperature_C'] * X_train_df['humidity_percent']
X_test_df['temp_humidity_interaction'] = X_test_df['temperature_C'] * X_test_df['humidity_percent']

X_train_df['aqi_squared'] = X_train_df['air_quality_index'] ** 2
X_test_df['aqi_squared'] = X_test_df['air_quality_index'] ** 2

all_features = list(X_train_df.columns)
print(f"    Features: {len(all_features)}")

# Get final arrays
X_train = X_train_df.values
X_test = X_test_df.values

print(f"    X_train shape: {X_train.shape}")
print(f"    X_test shape: {X_test.shape}")
print(f"    Cleaned training samples: {X_train.shape[0]}")

# ============================================================================
# SECTION 4: PREPROCESSING
# ============================================================================
print("\n[4] PREPROCESSING...")

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

print("    Scaling applied")

# ============================================================================
# SECTION 5: MODEL TRAINING
# ============================================================================
print("\n[5] MODEL TRAINING...")

# Split for validation
X_train_split, X_val, y_train_split, y_val = train_test_split(
    X_train_scaled, y_train, test_size=0.2, random_state=42
)

print(f"    Training set: {X_train_split.shape[0]}")
print(f"    Validation set: {X_val.shape[0]}")

# Train model
model = Ridge(alpha=1.0)
model.fit(X_train_split, y_train_split)

# Evaluate
y_pred_train = model.predict(X_train_split)
y_pred_val = model.predict(X_val)

train_rmse = np.sqrt(mean_squared_error(y_train_split, y_pred_train))
train_mae = mean_absolute_error(y_train_split, y_pred_train)
train_r2 = r2_score(y_train_split, y_pred_train)

val_rmse = np.sqrt(mean_squared_error(y_val, y_pred_val))
val_mae = mean_absolute_error(y_val, y_pred_val)
val_r2 = r2_score(y_val, y_pred_val)

print(f"\n    TRAINING METRICS:")
print(f"    RMSE: {train_rmse:.4f}")
print(f"    MAE:  {train_mae:.4f}")
print(f"    R2:   {train_r2:.4f}")

print(f"\n    VALIDATION METRICS:")
print(f"    RMSE: {val_rmse:.4f}")
print(f"    MAE:  {val_mae:.4f}")
print(f"    R2:   {val_r2:.4f}")

# ============================================================================
# SECTION 6: CROSS VALIDATION
# ============================================================================
print("\n[6] CROSS VALIDATION (5-FOLD)...")

cv_scores = cross_val_score(model, X_train_scaled, y_train, cv=5, 
                            scoring='neg_mean_squared_error')
cv_rmse = np.sqrt(-cv_scores)

print(f"    CV RMSE: {cv_rmse.mean():.4f} (+/- {cv_rmse.std():.4f})")

# ============================================================================
# SECTION 7: TEST PREDICTIONS
# ============================================================================
print("\n[7] GENERATING TEST PREDICTIONS...")

y_pred_test = model.predict(X_test_scaled)
y_pred_test_clipped = np.clip(y_pred_test, 0, 100)

print(f"    Min score: {y_pred_test_clipped.min():.2f}")
print(f"    Max score: {y_pred_test_clipped.max():.2f}")
print(f"    Mean score: {y_pred_test_clipped.mean():.2f}")

# ============================================================================
# SECTION 8: SAVE SUBMISSION
# ============================================================================
print("\n[8] SAVING SUBMISSION FILE...")

submission = pd.DataFrame({
    'id': range(len(y_pred_test_clipped)),
    'fire_risk_score': y_pred_test_clipped
})

submission.to_csv(OUTPUT_FILE, index=False)
print(f"    Saved to: {OUTPUT_FILE}")
print(f"    Records: {len(submission)}")

# ============================================================================
# SECTION 9: SAVE MODELS
# ============================================================================
print("\n[9] SAVING MODELS...")

joblib.dump(model, 'fire_risk_model.pkl')
joblib.dump(scaler, 'fire_risk_scaler.pkl')
joblib.dump(all_features, 'fire_risk_features.pkl')

print("    Model saved")
print("    Scaler saved")
print("    Features saved")

# ============================================================================
# SUMMARY
# ============================================================================
print("\n" + "=" * 70)
print("PIPELINE COMPLETE")
print("=" * 70)
print("\nGenerated Files:")
print(f"  - {OUTPUT_FILE} (Test predictions)")
print("  - fire_risk_model.pkl (Trained model)")
print("  - fire_risk_scaler.pkl (Feature scaler)")
print("  - fire_risk_features.pkl (Feature names)")

print("\nFinal Metrics:")
print(f"  Train RMSE: {train_rmse:.4f}")
print(f"  Val RMSE:   {val_rmse:.4f}")
print(f"  CV RMSE:    {cv_rmse.mean():.4f}")

print("\n[OK] SUCCESS - Fire risk prediction complete!")
print("=" * 70)
